<?php
/*------------------------------------------------------------------------
# mod_travelinsurance
# ------------------------------------------------------------------------
# author    Gokila Priya Bose - Weblogicx India http://www.weblogicxindia.com
# copyright Copyright (C) 2014 - 19 Weblogicxindia.com. All Rights Reserved.
# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: http://weblogicxindia.com
# Technical Support:  Forum - http://weblogicxindia.com/forum/index.html
-------------------------------------------------------------------------*/
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
JFactory::getLanguage()->load('com_travelinsurance', JPATH_ADMINISTRATOR);
include_once JPATH_LIBRARIES.'/fof/include.php';

// Load FOF if not already loaded
if (!defined('FOF_INCLUDED'))
{
  $paths = array(
    (defined('JPATH_LIBRARIES') ? JPATH_LIBRARIES : JPATH_ROOT . '/libraries') . '/fof/include.php',
    __DIR__ . '/fof/include.php',
  );

  foreach ($paths as $filePath)
  {
    if (!defined('FOF_INCLUDED') && file_exists($filePath))
    {
      include_once $filePath;
    }
  }
}

$app = JFactory::getApplication();

$geozone = $params->get( 'geozone', '1' );
$startdate = $params->get( 'show_startdate');
$enddate = $params->get( 'show_enddate');

$layout = 'item';

if($geozone && $geozone !="*"){
	$layout = 'itemyear';
}

$config = array(
		'option'	=> 'com_travelinsurance',
		'view'		=> 'order',
		'layout'		=> $layout,
		'input'		=> array(
		'task'		=> 'add',
		'geozone'	=>	$geozone,
		'show_startdate' =>	$startdate,
		'show_enddate' =>	$enddate,
		'caching'	=> false
	)
);

//$input = new FOFInput($config);

FOFDispatcher::getTmpInstance('com_travelinsurance', 'order', $config)->dispatch();